﻿from __future__ import annotations

import json
import base64
import binascii
import io
import mimetypes
import os
import platform
import secrets
import shutil
import ssl
import hashlib
import socket
import time
import uuid
import zipfile
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib import error as urlerror
from urllib import request as urlrequest
from urllib.parse import parse_qs, urlencode, urlparse
from xml.sax.saxutils import escape

from lockfix.config import load_config
from lockfix.controller import LockFixController
from lockfix.identity import slot_uid
from lockfix.integrated import integrated_solution_summary
from lockfix.source_inventory import integrated_source_inventory
from lockfix.veeam_client import VeeamClient, VeeamSettings


ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "web" / "static"
DEFAULT_CONFIG = ROOT / "config" / "lockfix.example.json"


class WebContext:
    def __init__(self, config_path: Path) -> None:
        self.config_path = config_path
        self.sessions = {}
        self.qr_tokens = {}
        self.license_path = ROOT / "runtime" / "license.json"
        self.report_customer_path = ROOT / "runtime" / "report_customer.json"
        self.report_extras_path = ROOT / "runtime" / "report_extras.json"

    @property
    def config(self):
        return load_config(self.config_path)

    @property
    def controller(self) -> LockFixController:
        return LockFixController(self.config)


class LockFixWebHandler(BaseHTTPRequestHandler):
    context: WebContext
    session_ttl_seconds = 60 * 60 * 8

    def log_message(self, format: str, *args: object) -> None:
        print("[webui] " + format % args)

    def do_GET(self) -> None:
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/":
                self.serve_file(STATIC_DIR / "index.html")
            elif parsed.path.startswith("/static/"):
                self.serve_file(STATIC_DIR / parsed.path[len("/static/") :])
            elif parsed.path == "/api/session":
                self.send_json({"authenticated": self.is_authenticated(), "license": self.license_status()})
            elif parsed.path == "/api/console/status":
                self.require_auth()
                self.send_json(self.console_status())
            elif parsed.path == "/api/qr-login/status":
                token = parse_qs(parsed.query).get("token", [""])[0]
                response = self.qr_status_response(token)
                headers = {}
                if response.get("approved") and response.get("session"):
                    headers["Set-Cookie"] = f"lockfix_session={response['session']}; HttpOnly; SameSite=Lax; Path=/"
                self.send_json(response, headers=headers)
            elif parsed.path == "/api/summary":
                self.require_auth()
                self.send_json(self.summary())
            elif parsed.path == "/api/audit":
                self.require_auth()
                self.send_json({"items": self.audit_items()})
            elif parsed.path == "/api/integrated":
                self.require_auth()
                self.send_json(integrated_solution_summary())
            elif parsed.path == "/api/monitoring":
                self.require_auth()
                params = parse_qs(parsed.query)
                self.send_json(self.monitoring_summary(params.get("start", [""])[0], params.get("end", [""])[0]))
            elif parsed.path == "/api/monitoring.csv":
                self.require_auth()
                params = parse_qs(parsed.query)
                self.send_monitoring_csv(params.get("start", [""])[0], params.get("end", [""])[0])
            elif parsed.path == "/api/report":
                self.require_auth()
                self.send_json(self.report_summary())
            elif parsed.path == "/api/report/extras":
                self.require_auth()
                self.send_json(self.report_extras_record())
            elif parsed.path == "/api/report.csv":
                self.require_auth()
                self.send_report_csv()
            elif parsed.path == "/api/report.xlsx":
                self.require_auth()
                self.send_report_xlsx()
            elif parsed.path == "/api/report.docx":
                self.require_auth()
                self.send_report_docx()
            elif parsed.path == "/api/dashboard":
                self.require_auth()
                self.send_json(self.dashboard_summary())
            elif parsed.path == "/api/notification":
                self.require_auth()
                self.send_json({"items": self.notification_items()})
            elif parsed.path == "/api/detect":
                self.require_auth()
                self.send_json(self.detect_summary())
            elif parsed.path == "/api/network-status":
                self.require_auth()
                self.send_json(self.network_status_summary())
            elif parsed.path == "/api/veeam-backup":
                self.require_auth()
                self.send_json(self.veeam_backup_summary())
            elif parsed.path == "/api/logs":
                self.require_auth()
                params = parse_qs(parsed.query)
                self.send_json(
                    self.logs_summary(
                        params.get("start", [""])[0],
                        params.get("end", [""])[0],
                        params.get("page", ["1"])[0],
                        params.get("retention", ["30"])[0],
                    )
                )
            elif parsed.path == "/api/logs.csv":
                self.require_auth()
                params = parse_qs(parsed.query)
                self.send_logs_csv(params.get("start", [""])[0], params.get("end", [""])[0], params.get("retention", ["30"])[0])
            elif parsed.path == "/api/license":
                self.require_auth()
                self.send_json(self.license_status())
            elif parsed.path == "/api/sources":
                self.require_auth()
                inventory = integrated_source_inventory()
                inventory["air_gap"] = self.air_gap_summary()
                self.send_json(inventory)
            else:
                self.send_error(404, "not found")
        except PermissionError as exc:
            self.send_json({"error": str(exc)}, status=401)
        except Exception as exc:
            self.send_json({"error": str(exc)}, status=500)

    def do_POST(self) -> None:
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/api/login":
                payload = self.read_json_body()
                email = str(payload.get("email", "")).strip()
                password = str(payload.get("password", ""))
                if secrets.compare_digest(email, "admin") and secrets.compare_digest(password, "1"):
                    token = secrets.token_urlsafe(32)
                    self.context.sessions[token] = time.time()
                    self.send_json(
                        {"authenticated": True},
                        headers={"Set-Cookie": f"lockfix_session={token}; HttpOnly; SameSite=Lax; Path=/"},
                    )
                else:
                    self.send_json({"authenticated": False, "error": "Invalid account."}, status=401)
            elif parsed.path == "/api/qr-login":
                token = secrets.token_urlsafe(24)
                self.context.qr_tokens[token] = {"created_at": time.time(), "approved": False}
                self.send_json({"token": token, "expires_in": 300, "payload": f"LOCKFIX-QR:{token}"})
            elif parsed.path == "/api/qr-login/confirm":
                payload = self.read_json_body()
                token = str(payload.get("token", ""))
                record = self.context.qr_tokens.get(token)
                if not record or time.time() - record["created_at"] > 300:
                    self.send_json({"approved": False, "error": "QR token expired."}, status=410)
                else:
                    record["approved"] = True
                    response = self.qr_status_response(token)
                    headers = {}
                    if response.get("approved") and response.get("session"):
                        headers["Set-Cookie"] = f"lockfix_session={response['session']}; HttpOnly; SameSite=Lax; Path=/"
                    self.send_json(response, headers=headers)
            elif parsed.path == "/api/logout":
                token = self.session_token()
                if token:
                    self.context.sessions.pop(token, None)
                self.send_json(
                    {"authenticated": False},
                    headers={"Set-Cookie": "lockfix_session=; Max-Age=0; HttpOnly; SameSite=Lax; Path=/"},
                )
            elif parsed.path == "/api/license/register":
                self.require_auth()
                payload = self.read_json_body()
                self.send_json(self.register_license(payload))
            elif parsed.path == "/api/report/customer":
                self.require_auth()
                payload = self.read_json_body()
                self.send_json(self.save_report_customer(payload))
            elif parsed.path == "/api/report/extras":
                self.require_auth()
                payload = self.read_json_body()
                self.send_json(self.save_report_extras(payload))
            elif parsed.path == "/api/isolate":
                self.require_auth()
                slot_id = self.query_slot(parsed.query)
                state = self.context.controller.isolate(slot_id)
                self.send_json({"slot_id": slot_id, "state": state.value, "summary": self.summary()})
            elif parsed.path == "/api/reconnect":
                self.require_auth()
                slot_id = self.query_slot(parsed.query)
                state = self.context.controller.reconnect(slot_id)
                self.send_json({"slot_id": slot_id, "state": state.value, "summary": self.summary()})
            else:
                self.send_error(404, "not found")
        except PermissionError as exc:
            self.send_json({"error": str(exc)}, status=401)
        except Exception as exc:
            self.send_json({"error": str(exc), "summary": self.summary()}, status=500)

    def query_slot(self, query: str) -> str:
        values = parse_qs(query)
        slot_id = values.get("slot", [""])[0]
        if not slot_id:
            raise ValueError("slot query parameter is required")
        return slot_id

    def read_json_body(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        raw = self.rfile.read(length).decode("utf-8")
        return json.loads(raw or "{}")

    def report_customer_record(self) -> dict:
        try:
            return json.loads(self.context.report_customer_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def save_report_customer(self, payload: dict) -> dict:
        record = {
            "customer_contact": str(payload.get("customer_contact", "")).strip() or "-",
            "customer_email": str(payload.get("customer_email", "")).strip() or "-",
        }
        self.context.report_customer_path.parent.mkdir(parents=True, exist_ok=True)
        self.context.report_customer_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        return {"ok": True, "customer": record}

    def report_extras_record(self) -> dict:
        try:
            record = json.loads(self.context.report_extras_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            record = {}
        return {
            "engineer_opinion": str(record.get("engineer_opinion", "")),
            "engineer_signature": str(record.get("engineer_signature", "")),
            "manager_signature": str(record.get("manager_signature", "")),
        }

    def save_report_extras(self, payload: dict) -> dict:
        record = {
            "engineer_opinion": str(payload.get("engineer_opinion", "")).strip(),
            "engineer_signature": self.clean_image_data_url(payload.get("engineer_signature", "")),
            "manager_signature": self.clean_image_data_url(payload.get("manager_signature", "")),
        }
        self.context.report_extras_path.parent.mkdir(parents=True, exist_ok=True)
        self.context.report_extras_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        return {"ok": True, **record}

    def clean_image_data_url(self, value: object) -> str:
        text = str(value or "")
        if not text.startswith("data:image/png;base64,"):
            return ""
        try:
            base64.b64decode(text.split(",", 1)[1], validate=True)
        except (ValueError, binascii.Error):
            return ""
        return text

    def image_data_url_bytes(self, value: str) -> bytes:
        if not value.startswith("data:image/png;base64,"):
            return b""
        try:
            return base64.b64decode(value.split(",", 1)[1], validate=True)
        except (ValueError, binascii.Error):
            return b""

    def session_token(self):
        cookie = self.headers.get("Cookie", "")
        for part in cookie.split(";"):
            name, _, value = part.strip().partition("=")
            if name == "lockfix_session":
                return value
        return None

    def is_authenticated(self) -> bool:
        token = self.session_token()
        if not token:
            return False
        created_at = self.context.sessions.get(token)
        if not created_at:
            return False
        if time.time() - created_at > self.session_ttl_seconds:
            self.context.sessions.pop(token, None)
            return False
        return True

    def license_identity(self) -> dict:
        try:
            ip_address = socket.gethostbyname(socket.gethostname())
        except OSError:
            ip_address = "127.0.0.1"
        mac_raw = f"{uuid.getnode():012x}"
        mac_address = ":".join(mac_raw[index : index + 2] for index in range(0, 12, 2)).upper()
        return {"ip_address": ip_address, "mac_address": mac_address}

    def license_key_for(self, customer: str, support_code: str, ip_address: str = "", mac_address: str = "") -> str:
        seed = "|".join(["LOCK-FIX", customer.strip().upper(), support_code.strip().upper()])
        digest = hashlib.sha256(seed.encode("utf-8")).hexdigest().upper()[:20]
        return "LF-" + "-".join(digest[index : index + 4] for index in range(0, 20, 4))

    def load_license_record(self) -> dict:
        if not self.context.license_path.exists():
            return {}
        try:
            return json.loads(self.context.license_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def save_license_record(self, record: dict) -> None:
        self.context.license_path.parent.mkdir(parents=True, exist_ok=True)
        self.context.license_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")

    def license_status(self) -> dict:
        identity = self.license_identity()
        record = self.load_license_record()
        now = datetime.now()
        status = {
            "valid": False,
            "reason": "not_registered",
            "customer": record.get("customer", ""),
            "support_code": record.get("support_code", ""),
            "license_key": record.get("license_key", ""),
            "issued_at": record.get("issued_at", ""),
            "expires_at": record.get("expires_at", ""),
            "updated_at": record.get("updated_at", ""),
            "days_left": 0,
            "identity": identity,
            "registered_identity": record.get("identity", {}),
            "sample_key": self.license_key_for("OAM-CUSTOMER", "OAM"),
        }
        if not record:
            return status

        if not record.get("license_key"):
            status["reason"] = "invalid_key"
            return status

        try:
            expires_at = datetime.fromisoformat(record["expires_at"])
        except (KeyError, ValueError):
            status["reason"] = "invalid_expiry"
            return status

        days_left = (expires_at.date() - now.date()).days
        status["days_left"] = max(0, days_left)
        if days_left < 0:
            status["reason"] = "expired"
            self.write_audit_event_once("license_expired", license_key=record.get("license_key", ""), expires_at=record.get("expires_at", ""))
            return status
        if days_left <= 30:
            self.write_audit_event_once("license_expiry_warning", days_left=days_left, expires_at=record.get("expires_at", ""))
        status["valid"] = True
        status["reason"] = "valid"
        return status

    def register_license(self, payload: dict) -> dict:
        customer = str(payload.get("customer", "")).strip() or "OAM-CUSTOMER"
        support_code = str(payload.get("support_code", "")).strip() or "OAM"
        license_key = str(payload.get("license_key", "")).strip().upper()
        identity = self.license_identity()
        expected_key = self.license_key_for(customer, support_code)
        if not secrets.compare_digest(license_key, expected_key):
            self.write_audit_event("license_register_failed", customer=customer, reason="invalid_key")
            return {"ok": False, "error": "라이선스 키가 고객사/Support Code 정보와 일치하지 않습니다.", "expected_sample": expected_key}
        now = datetime.now()
        record = {
            "customer": customer,
            "support_code": support_code,
            "license_key": license_key,
            "identity": identity,
            "issued_at": now.isoformat(timespec="seconds"),
            "expires_at": (now + timedelta(days=365)).isoformat(timespec="seconds"),
            "updated_at": now.isoformat(timespec="seconds"),
        }
        self.save_license_record(record)
        self.write_audit_event("license_registered", customer=customer, support_code=support_code, expires_at=record["expires_at"])
        return {"ok": True, "license": self.license_status()}

    def write_audit_event(self, event: str, **payload) -> None:
        self.context.config.audit_log_path.parent.mkdir(parents=True, exist_ok=True)
        record = {"ts": datetime.now().isoformat(timespec="seconds"), "event": event, **payload}
        with self.context.config.audit_log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    def write_audit_event_once(self, event: str, **payload) -> None:
        today_key = f"{event}:{datetime.now().date().isoformat()}"
        marker = ROOT / "runtime" / "license_events.json"
        events = []
        if marker.exists():
            try:
                events = json.loads(marker.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                events = []
        if today_key in events:
            return
        self.write_audit_event(event, **payload)
        events.append(today_key)
        marker.write_text(json.dumps(events[-120:], ensure_ascii=False), encoding="utf-8")

    def qr_status_response(self, token: str) -> dict:
        record = self.context.qr_tokens.get(token)
        if not record:
            return {"approved": False, "expired": True}
        if time.time() - record["created_at"] > 300:
            self.context.qr_tokens.pop(token, None)
            return {"approved": False, "expired": True}
        if not record.get("approved"):
            return {"approved": False, "expired": False}

        session = secrets.token_urlsafe(32)
        self.context.sessions[session] = time.time()
        self.context.qr_tokens.pop(token, None)
        return {
            "approved": True,
            "expired": False,
            "session": session,
        }

    def require_auth(self) -> None:
        if not self.is_authenticated():
            raise PermissionError("authentication required")

    def summary(self) -> dict:
        config = self.context.config
        status = self.context.controller.status()
        slots = []
        for slot_id, slot in config.slots.items():
            mount = self.mount_summary(slot.mount_point)
            slots.append(
                {
                    "slot_id": slot_id,
                    "state": status.get(slot_id, "READY_MOCK"),
                    "device": slot.device,
                    "mount_point": str(slot.mount_point),
                    "mount": mount,
                    "power_type": slot.power.type,
                    "dry_run": config.dry_run,
                    "uid": slot_uid(slot),
                    "expected_uid": slot.expected_uid,
                }
            )
        return {
            "dry_run": config.dry_run,
            "config_path": str(self.context.config_path),
            "audit_log_path": str(config.audit_log_path),
            "slots": slots,
        }

    def console_status(self) -> dict:
        return {
            "title": "LOCK-FIX Web UI Console",
            "mode": "python_function",
            "cmd_execution": False,
            "url": "http://127.0.0.1:8088",
            "root": str(ROOT),
            "config_path": str(self.context.config_path.resolve()),
            "webui_path": str((ROOT / "webui.py").resolve()),
            "python_runtime": "direct Python function/API",
            "server": {
                "running": True,
                "handler": "LockFixWebHandler",
                "entrypoint": "run(host, port, config_path)",
            },
            "message": "Web UI status is provided by Python functions. No .cmd execution is required from the browser.",
        }

    def air_gap_summary(self) -> dict:
        summary = self.summary()
        now = time.time()
        tick = int(now)
        veeam_runtime = self.veeam_interlock_runtime(now)
        current_step = veeam_runtime["current_step"]
        veeam_states = [
            {"step": 1, "title": "Backup completed", "label": "백업 완료", "state": "PENDING", "code": "BACKUP_COMPLETED"},
            {"step": 2, "title": "Flush running", "label": "Flush 실행", "state": "PENDING", "code": "FLUSHING"},
            {"step": 3, "title": "I/O checking", "label": "I/O 종료 확인", "state": "PENDING", "code": "IO_CHECKING"},
            {"step": 4, "title": "Unmount", "label": "Unmount", "state": "PENDING", "code": "UNMOUNTING"},
            {"step": 5, "title": "Power off", "label": "전원 OFF", "state": "PENDING", "code": "POWERING_OFF"},
        ]
        for item in veeam_states:
            if item["step"] < current_step:
                item["state"] = "DONE"
            elif item["step"] == current_step:
                item["state"] = "ACTIVE"
            item["checked_at"] = veeam_runtime["last_checked"]
            item["log"] = veeam_runtime["step_logs"][item["step"] - 1]
        bays = []
        for index, slot in enumerate(summary["slots"], start=1):
            locked = (tick + index) % 5 != 0
            hash_suffix = hashlib.sha256(f"{slot['slot_id']}|{slot['uid']}".encode("utf-8")).hexdigest()[:12].upper()
            bays.append(
                {
                    "slot": slot["slot_id"],
                    "device": slot["device"],
                    "mount_point": slot["mount_point"],
                    "power": {
                        "state": "CUT_OFF",
                        "label": "Physical Power Cut-off Complete",
                        "description": "Hard Power-Off circuit is open and the data path is physically isolated.",
                    },
                    "lock": {
                        "state": "LOCKED" if locked else "READY",
                        "label": "Locked" if locked else "Ready to Unlock",
                        "description": "External physical access is blocked." if locked else "Ready for removal after administrator approval.",
                    },
                    "integrity": {
                        "uid": "Drive #%s - Match" % index,
                        "hash": "SHA-256 Hash - Valid",
                        "hash_value": f"SHA256-{hash_suffix}",
                        "blocked": False,
                    },
                }
            )
        return {
            "security_score": {
                "score": 98,
                "status": "SAFE AIR-GAP",
                "description": "Power cut-off, solenoid lock, and integrity verification are all operating normally.",
            },
            "kpis": [
                {
                    "id": "power",
                    "title": "Power Cut-off",
                    "value": "Physical Cut-off Complete",
                    "detail": "Hard power isolation, not a software-only unmount.",
                },
                {
                    "id": "lock",
                    "title": "Solenoid Lock",
                    "value": "Locked",
                    "detail": "Mechanical lock is engaged on the drive bay.",
                },
                {
                    "id": "integrity",
                    "title": "Integrity Check",
                    "value": "Verified",
                    "detail": "UID match and SHA-256 hash validation passed.",
                },
            ],
            "veeam": {
                "api_poll_interval_seconds": 1,
                "server": veeam_runtime["server"],
                "port": veeam_runtime["port"],
                "connected": veeam_runtime["connected"],
                "last_checked": veeam_runtime["last_checked"],
                "job": veeam_runtime["job"],
                "session_state": veeam_states[current_step - 1]["code"],
                "current_step": current_step,
                "state_source": veeam_runtime["state_source"],
                "api_synced": veeam_runtime["api_synced"],
                "port_open": veeam_runtime["port_open"],
                "api_checks": veeam_runtime["api_checks"],
                "auto_isolate": veeam_runtime["auto_isolate"],
                "progress_percent": veeam_runtime["progress_percent"],
                "api_verification_percent": veeam_runtime["api_verification_percent"],
                "message": veeam_runtime["message"],
            },
            "timeline": veeam_states,
            "step_logs": veeam_runtime["step_logs"],
            "session_logs": veeam_runtime["session_logs"],
            "bays": bays,
            "integrity_history": [
                {"time": "2026-04-25 22:40:13", "target": "Backup Cycle #1042", "uid": "MATCH", "hash": "VALID"},
                {"time": "2026-04-25 12:00:10", "target": "Backup Cycle #1041", "uid": "MATCH", "hash": "VALID"},
                {"time": "2026-04-24 23:58:44", "target": "Backup Cycle #1040", "uid": "MATCH", "hash": "VALID"},
            ],
            "emergency": {
                "title": "Emergency Control Center",
                "description": "Manual release is available only after two-administrator approval.",
                "primary": "Waiting for Dual Approval",
                "secondary": "Data path activation remains blocked",
            },
        }

    def veeam_interlock_runtime(self, now: float) -> dict:
        runtime_path = ROOT / "runtime" / "veeam_interlock_state.json"
        payload = {}
        if runtime_path.exists():
            try:
                payload = json.loads(runtime_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                payload = {}

        install_props = self.veeam_install_properties()
        server = str(payload.get("server") or os.environ.get("LOCKFIX_VEEAM_HOST") or install_props.get("veeam_host") or "127.0.0.1")
        port = int(payload.get("port") or os.environ.get("LOCKFIX_VEEAM_PORT") or install_props.get("veeam_port") or 9419)
        port_open = self.tcp_port_open(server, port)
        api_payload = self.poll_veeam_api(server, port, payload)
        if api_payload:
            merged = dict(payload)
            merged.update(api_payload)
            payload = merged
        api_synced = bool(payload.get("api_synced"))
        has_api_session = api_synced
        current_step = int(payload.get("current_step") or 1)
        current_step = max(1, min(5, current_step))
        if not has_api_session:
            current_step = 1
        progress = int(payload.get("progress_percent") or payload.get("progress") or max(0, (current_step - 1) * 25))
        progress = max(0, min(100, progress))
        raw_result = str(payload.get("result") or payload.get("status") or "").upper()
        if raw_result in {"SUCCESS", "SUCCEEDED", "COMPLETED"}:
            progress = 100
        if not has_api_session:
            progress = 0
        connected = bool(has_api_session)
        api_verification_percent = 100 if connected else 0
        last_checked = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now))
        job = str(payload.get("job") or "LOCK-FIX-AIRGAP-BACKUP")
        state_source = payload.get("state_source") or ("veeam_rest_api" if payload.get("api_synced") else "runtime/veeam_interlock_state.json" if payload else "waiting_for_veeam_api")
        labels = ["백업 완료", "Flush 실행", "I/O 종료 확인", "Unmount", "전원 OFF"]
        codes = ["BACKUP_COMPLETED", "FLUSHING", "IO_CHECKING", "UNMOUNTING", "POWERING_OFF"]
        step_logs = []
        custom_logs = payload.get("step_logs") if connected and isinstance(payload.get("step_logs"), list) else []
        for index, label in enumerate(labels, start=1):
            state = "PENDING"
            if index < current_step:
                state = "DONE"
            elif index == current_step:
                state = "ACTIVE"
            custom = custom_logs[index - 1] if index - 1 < len(custom_logs) and isinstance(custom_logs[index - 1], dict) else {}
            if index == 1:
                default_detail = (
                    f"Veeam API 연동 {api_verification_percent}% 확인. 백업 수행 진행률 {progress}% 확인."
                    if connected
                    else f"Veeam API 연결 대기 중. 백업 수행 진행률 {progress}% 상태로 단계 전환을 보류합니다."
                )
            elif index < current_step:
                default_detail = f"{label} 단계 완료. Veeam API 상태 전환 로그와 백업 진행률 {progress}%를 기록했습니다."
            elif index == current_step:
                default_detail = "현재 단계입니다. 다음 단계 전환 신호가 확인될 때까지 색상을 유지합니다."
            else:
                default_detail = "아직 이전 단계 완료 신호가 확인되지 않았습니다."
            step_logs.append(
                {
                    "step": index,
                    "label": label,
                    "code": codes[index - 1],
                    "state": custom.get("state") or state,
                    "time": custom.get("time") or last_checked,
                    "source": custom.get("source") or ("Veeam API" if connected else "Veeam API 대기"),
                    "detail": custom.get("detail") or default_detail,
                    "progress_percent": custom.get("progress_percent", progress if index <= current_step else ""),
                    "api_verification_percent": custom.get("api_verification_percent", api_verification_percent if index == 1 else ""),
                    "transition_allowed": index <= current_step,
                }
            )
        started_at = payload.get("started_at") or payload.get("start_time") or last_checked
        ended_at = payload.get("ended_at") or payload.get("end_time") or (last_checked if progress >= 100 else "-")
        duration = payload.get("duration") or ("00:08" if progress >= 100 else "-")
        status = str(payload.get("status") or payload.get("result") or "").strip()
        if not status:
            status = "Success" if progress >= 100 else "Running" if connected else "Waiting"
        elif status.upper() in {"SUCCESS", "SUCCEEDED", "COMPLETED"}:
            status = "Success"
        elif status.upper() in {"FAILED", "FAILURE", "ERROR"}:
            status = "Failed"
        elif status.upper() in {"RUNNING", "WORKING", "INPROGRESS", "IN_PROGRESS"}:
            status = "Running"
        auto_isolate = self.auto_isolate_after_veeam_success(payload, status, last_checked) if connected else {
            "enabled": True,
            "triggered": False,
            "message": "Waiting for successful Veeam session.",
        }
        payload["auto_isolate"] = auto_isolate
        if auto_isolate.get("state") == "ISOLATED":
            current_step = 5
            progress = 100
            for item in step_logs:
                step_number = int(item.get("step") or 0)
                item["state"] = "DONE" if step_number < 5 else "ACTIVE"
                item["transition_allowed"] = step_number <= 5
                item["progress_percent"] = 100
                if step_number == 5:
                    item["detail"] = auto_isolate.get("message") or "Veeam success detected. LOCK-FIX isolate completed."

        session_logs = []
        raw_session_logs = payload.get("session_logs") if connected and isinstance(payload.get("session_logs"), list) else []
        if not raw_session_logs and connected and isinstance(payload.get("logs"), list):
            raw_session_logs = payload.get("logs")
        for entry in raw_session_logs:
            if not isinstance(entry, dict):
                continue
            actions = entry.get("actions") if isinstance(entry.get("actions"), list) else []
            action = entry.get("action") or entry.get("message") or entry.get("detail")
            if action:
                actions.append(action)
            checks = payload.get("checks") if isinstance(payload.get("checks"), dict) else {}
            for key in ("port_9419", "token", "sessions"):
                check = checks.get(key) if isinstance(checks.get(key), dict) else {}
                if check:
                    state = "OK" if check.get("ok") else "WAIT"
                    actions.append(f"{state} - {check.get('message') or key}")
            em_check = checks.get("enterprise_manager") if isinstance(checks.get("enterprise_manager"), dict) else {}
            if em_check:
                actions.append(
                    "INFO - Enterprise Manager 9398 is reference-only diagnostics and does not affect LOCK-FIX 9419 validation."
                )
            if auto_isolate.get("message"):
                state = "OK" if auto_isolate.get("state") == "ISOLATED" else "WAIT"
                actions.append(f"{state} - {auto_isolate.get('message')}")
            session_logs.append(
                {
                    "name": entry.get("name") or entry.get("job") or job,
                    "status": entry.get("status") or status,
                    "actions": actions,
                    "duration": entry.get("duration") or duration,
                    "progress_percent": entry.get("progress_percent", progress),
                    "started_at": entry.get("started_at") or started_at,
                    "ended_at": entry.get("ended_at") or ended_at,
                }
            )
        if not connected:
            waiting_actions = [
                f"Veeam REST API is not synced. Check host, port, credentials, or token for {server}:{port}.",
                "LOCK-FIX keeps the interlock procedure at step 1 until a real Veeam API session is received.",
            ]
            checks = payload.get("checks") if isinstance(payload.get("checks"), dict) else {}
            for key in ("port_9419", "token", "sessions"):
                check = checks.get(key) if isinstance(checks.get(key), dict) else {}
                if check:
                    state = "OK" if check.get("ok") else "WAIT"
                    waiting_actions.append(f"{state} - {check.get('message') or key}")
            em_check = checks.get("enterprise_manager") if isinstance(checks.get("enterprise_manager"), dict) else {}
            if em_check:
                waiting_actions.append(
                    "INFO - Enterprise Manager 9398 is reference-only diagnostics and does not affect LOCK-FIX 9419 validation."
                )
            session_logs = [
                {
                    "name": "Veeam API",
                    "status": "Waiting",
                    "actions": waiting_actions,
                    "duration": "-",
                    "progress_percent": 0,
                    "started_at": "-",
                    "ended_at": "-",
                }
            ]
        elif not session_logs:
            backup_size = payload.get("backup_size") or "0 B"
            transferred = payload.get("transferred") or backup_size
            speed = payload.get("speed") or ("0 KB/s" if progress >= 100 else "-")
            target = payload.get("target") or server
            actions = [f"Backup copy for {job} - {target} started at {started_at}"]
            stage_labels = {
                1: "Backup completion verification",
                2: "Flush execution",
                3: "I/O quiet check",
                4: "Unmount protection and execution",
                5: "Power off",
            }
            try:
                elapsed_seconds = int(payload.get("stage_elapsed_seconds") or payload.get("elapsed_seconds") or max(1, now - float(payload.get("stage_started_epoch", now))))
            except (TypeError, ValueError):
                elapsed_seconds = 1
            elapsed_seconds = max(1, min(300, elapsed_seconds))
            stage_label = stage_labels.get(current_step, "Interlock execution")
            if current_step in {2, 3, 4}:
                for elapsed in range(1, elapsed_seconds + 1):
                    actions.append(f"{stage_label} tick {elapsed}s - {job} - {target} progress {progress}%")
                if current_step == 4:
                    actions.append("Unmount guard active: C:\\ OS volume is protected and cannot be selected as an unmount target.")
            elif progress >= 100:
                actions.append(f"{job} - {target} ({backup_size}) processing finished at {ended_at}: {transferred} transferred at {speed}")
            else:
                wait_message = "Waiting for the next Veeam API update." if port_open else "Veeam API port is not reachable."
                actions.append(f"{job} - {target} processing {progress}% complete. {wait_message}")
            session_logs.append(
                {
                    "name": payload.get("name") or job,
                    "status": status,
                    "actions": actions,
                    "duration": duration,
                    "progress_percent": progress,
                    "started_at": started_at,
                    "ended_at": ended_at,
                }
            )
        return {
            "server": server,
            "port": port,
            "connected": connected,
            "api_synced": api_synced,
            "port_open": port_open,
            "current_step": current_step,
            "last_checked": last_checked,
            "job": job,
            "state_source": state_source,
            "progress_percent": progress,
            "api_verification_percent": api_verification_percent,
            "payload": payload,
            "step_logs": step_logs,
            "session_logs": session_logs,
            "auto_isolate": auto_isolate,
            "api_checks": payload.get("checks") if isinstance(payload.get("checks"), dict) else {},
            "message": (
                "Veeam API is connected. Step colors change only when the current_step value advances."
                if connected
                else "Veeam API is not connected yet. Current step is held and colors will not advance automatically."
            ),
        }

    def veeam_backup_summary(self) -> dict:
        now = time.time()
        runtime = self.veeam_interlock_runtime(now)
        payload = runtime.get("payload") or {}
        current_step = runtime["current_step"]
        progress = int(payload.get("progress_percent") or payload.get("progress") or max(0, (current_step - 1) * 25))
        progress = max(0, min(100, progress))
        raw_result = str(payload.get("result") or payload.get("status") or "").upper()
        if raw_result in {"SUCCESS", "SUCCEEDED", "COMPLETED"}:
            result = "SUCCESS"
            progress = 100
        elif raw_result in {"FAILED", "FAILURE", "ERROR"}:
            result = "FAILED"
        elif raw_result in {"WARNING", "WARN"}:
            result = "WARNING"
        elif runtime["connected"]:
            result = "RUNNING"
        else:
            result = "WAITING"
            progress = 0

        started_at = payload.get("started_at") or payload.get("start_time") or "-"
        ended_at = payload.get("ended_at") or payload.get("end_time") or "-"
        duration = payload.get("duration") or "-"
        details = payload.get("logs") if isinstance(payload.get("logs"), list) else []
        if not details:
            details = [
                {
                    "time": item["time"],
                    "level": "INFO" if item["transition_allowed"] else "WAIT",
                    "step": item["step"],
                    "message": item["detail"],
                    "source": item["source"],
                }
                for item in runtime["step_logs"]
            ]

        return {
            "api": {
                "poll_interval_seconds": 1,
                "server": runtime["server"],
                "port": runtime["port"],
                "connected": runtime["connected"],
                "api_synced": runtime["api_synced"],
                "port_open": runtime["port_open"],
                "api_checks": runtime["api_checks"],
                "last_checked": runtime["last_checked"],
                "state_source": runtime["state_source"],
                "message": runtime["message"],
            },
            "job": {
                "name": runtime["job"],
                "session_state": payload.get("session_state") or payload.get("state") or runtime["step_logs"][current_step - 1]["code"],
                "current_step": current_step,
                "progress_percent": progress,
                "result": result,
                "started_at": started_at,
                "ended_at": ended_at,
                "duration": duration,
            },
            "steps": runtime["step_logs"],
            "session_logs": runtime["session_logs"],
            "auto_isolate": runtime["auto_isolate"],
            "logs": details,
        }

    def poll_veeam_api(self, server: str, port: int, local_payload: dict) -> dict:
        install_props = self.veeam_install_properties()
        base_url = (
            str(local_payload.get("base_url") or "").strip()
            or os.environ.get("LOCKFIX_VEEAM_BASE_URL", "").strip()
            or install_props.get("veeam_base_url", "").strip()
            or self.config.veeam.base_url.strip()
            or f"https://{server}:{port}"
        ).rstrip("/")
        enterprise_manager_url = (
            str(local_payload.get("enterprise_manager_url") or "").strip()
            or os.environ.get("LOCKFIX_VEEAM_EM_BASE_URL", "").strip()
            or install_props.get("veeam_enterprise_manager_url", "").strip()
            or self.config.veeam.enterprise_manager_url.strip()
            or "https://127.0.0.1:9398"
        ).rstrip("/")
        password_env = self.config.veeam.password_env or "LOCKFIX_VEEAM_PASSWORD"
        settings = VeeamSettings(
            base_url=base_url,
            enterprise_manager_url=enterprise_manager_url,
            username=str(local_payload.get("username") or os.environ.get("LOCKFIX_VEEAM_USER", "") or install_props.get("veeam_user", "") or self.config.veeam.username).strip(),
            password=str(os.environ.get(password_env, "") or os.environ.get("LOCKFIX_VEEAM_PASSWORD", "")).strip(),
            api_version=str(local_payload.get("api_version") or os.environ.get("LOCKFIX_VEEAM_API_VERSION", "") or install_props.get("veeam_api_version", "") or self.config.veeam.api_version or "1.2-rev1").strip(),
            verify_ssl=bool(local_payload.get("verify_ssl", self.config.veeam.verify_ssl)),
            job_name=str(local_payload.get("job_name") or self.config.veeam.job_name or "").strip(),
            job_id=str(local_payload.get("job_id") or self.config.veeam.job_id or "").strip(),
        )
        return VeeamClient(settings).latest_session_summary(settings.job_name, settings.job_id)

    def auto_isolate_after_veeam_success(self, payload: dict, status: str, checked_at: str) -> dict:
        result = str(payload.get("result") or status or "").upper()
        progress = int(payload.get("progress_percent") or payload.get("progress") or 0)
        if result not in {"SUCCESS", "SUCCEEDED", "COMPLETED"} and progress < 100:
            return {"enabled": True, "triggered": False, "message": "Veeam session is not successful yet."}
        slot_id = str(payload.get("slot_id") or os.environ.get("LOCKFIX_SLOT_ID") or next(iter(self.config.slots), "BAY-01"))
        session_key = "|".join(
            [
                str(payload.get("job") or payload.get("name") or "Veeam Backup"),
                str(payload.get("started_at") or "-"),
                str(payload.get("ended_at") or "-"),
            ]
        )
        marker_path = ROOT / "runtime" / "veeam_auto_isolate.json"
        try:
            previous = json.loads(marker_path.read_text(encoding="utf-8")) if marker_path.exists() else {}
        except (OSError, json.JSONDecodeError):
            previous = {}
        if previous.get("session_key") == session_key and previous.get("state") == "ISOLATED":
            return {
                "enabled": True,
                "triggered": False,
                "slot_id": slot_id,
                "session_key": session_key,
                "state": "ISOLATED",
                "message": "Successful session was already isolated.",
            }
        try:
            state = self.controller.isolate(slot_id)
            marker_path.parent.mkdir(parents=True, exist_ok=True)
            marker_path.write_text(
                json.dumps(
                    {
                        "session_key": session_key,
                        "slot_id": slot_id,
                        "state": state.value,
                        "checked_at": checked_at,
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
                encoding="utf-8",
            )
            return {
                "enabled": True,
                "triggered": True,
                "slot_id": slot_id,
                "session_key": session_key,
                "state": state.value,
                "message": "Veeam backup success detected. LOCK-FIX isolate was called automatically.",
            }
        except Exception as exc:
            return {
                "enabled": True,
                "triggered": False,
                "slot_id": slot_id,
                "session_key": session_key,
                "error": str(exc),
                "message": "Veeam backup success detected, but automatic isolate failed.",
            }

    def first_veeam_session(self, data: object) -> dict:
        if isinstance(data, dict):
            for key in ("data", "sessions", "results", "items", "value"):
                value = data.get(key)
                if isinstance(value, list) and value:
                    first = value[0]
                    return first if isinstance(first, dict) else {}
                if isinstance(value, dict):
                    found = self.first_veeam_session(value)
                    if found:
                        return found
            return data
        if isinstance(data, list) and data and isinstance(data[0], dict):
            return data[0]
        return {}

    def veeam_actions_from_session(self, session: dict) -> list[str]:
        raw_actions = session.get("actions") or session.get("log") or session.get("logs") or session.get("messages")
        actions = []
        if isinstance(raw_actions, list):
            for item in raw_actions:
                if isinstance(item, dict):
                    text = item.get("action") or item.get("message") or item.get("title") or item.get("description")
                    if text:
                        actions.append(str(text))
                elif item:
                    actions.append(str(item))
        elif raw_actions:
            actions.append(str(raw_actions))
        if not actions:
            name = str(session.get("name") or session.get("jobName") or "Veeam Backup")
            started = str(session.get("creationTime") or session.get("startTime") or "-")
            actions.append(f"Backup copy for {name} started at {started}")
        return actions

    def veeam_install_properties(self) -> dict:
        props_path = ROOT / "runtime" / "install.properties"
        if not props_path.exists():
            return {}
        result = {}
        try:
            for line in props_path.read_text(encoding="utf-8").splitlines():
                if not line or line.lstrip().startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                result[key.strip()] = value.strip()
        except OSError:
            return {}
        return result

    def tcp_port_open(self, host: str, port: int) -> bool:
        try:
            with socket.create_connection((host, port), timeout=0.35):
                return True
        except OSError:
            return False

    def mount_summary(self, mount_point: Path) -> dict:
        exists = mount_point.exists()
        is_dir = mount_point.is_dir()
        mounted = False
        usage = None
        error = None

        try:
            if exists and is_dir:
                usage_raw = shutil.disk_usage(str(mount_point))
                total = usage_raw.total
                used = usage_raw.used
                free = usage_raw.free
                usage = {
                    "total": total,
                    "used": used,
                    "free": free,
                    "percent": round((used / total) * 100, 1) if total else 0,
                    "total_label": self.format_bytes(total),
                    "used_label": self.format_bytes(used),
                    "free_label": self.format_bytes(free),
                }
                mounted = self.is_mount_point(mount_point)
        except OSError as exc:
            error = str(exc)

        return {
            "exists": exists,
            "is_dir": is_dir,
            "mounted": mounted,
            "usage": usage,
            "error": error,
        }

    def is_mount_point(self, mount_point: Path) -> bool:
        try:
            return mount_point.is_mount()
        except OSError:
            return False

    def format_bytes(self, value: int) -> str:
        size = float(value)
        for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
            if size < 1024 or unit == "PB":
                return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"
            size /= 1024
        return f"{size:.1f} PB"

    def audit_items(self) -> list[dict]:
        path = self.context.config.audit_log_path
        if not path.exists():
            return []
        lines = path.read_text(encoding="utf-8").splitlines()
        items = []
        for line in lines[-200:]:
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError:
                items.append({"event": "parse_error", "raw": line})
        return list(reversed(items))

    def monitoring_summary(self, start_date: str = "", end_date: str = "") -> dict:
        points = []
        now = datetime.now()
        range_start = now - timedelta(minutes=29 * 10)
        range_end = now
        try:
            if start_date:
                range_start = datetime.strptime(start_date, "%Y-%m-%d")
            if end_date:
                range_end = datetime.strptime(end_date, "%Y-%m-%d") + timedelta(hours=23, minutes=59)
            if range_end < range_start:
                range_end = range_start + timedelta(hours=23, minutes=59)
        except ValueError:
            range_start = now - timedelta(minutes=29 * 10)
            range_end = now
        total_seconds = max(29, int((range_end - range_start).total_seconds()))
        step_seconds = total_seconds / 29
        tick = int(time.time() / 5)
        for index in range(30):
            stamp = range_start + timedelta(seconds=step_seconds * index)
            phase = index + tick
            cpu = 12 + ((phase * 7) % 21) + (8 if phase % 11 in (1, 2) else 0)
            memory = 91.6 + ((phase % 7) * 0.22)
            disk = 14.0 + ((phase % 6) * 0.18)
            network = 18 + ((phase * 9) % 39) + (10 if phase % 13 == 0 else 0)
            interface = 22 + ((phase * 5) % 31) + (8 if phase % 10 == 0 else 0)
            points.append(
                {
                    "time": stamp.strftime("%Y.%m.%d %H:%M"),
                    "label": stamp.strftime("%m.%d %H:%M"),
                    "cpu": round(cpu, 1),
                    "memory": round(memory, 1),
                    "disk": round(disk, 1),
                    "network": round(network, 1),
                    "interface": round(interface, 1),
                }
            )
        latest = points[-1]
        return {
            "title": "OAM - Hardware Usage Monitoring",
            "interval_seconds": 5,
            "range": {
                "start": points[0]["time"],
                "end": points[-1]["time"],
            },
            "series": points,
            "current": {
                "cpu": latest["cpu"],
                "memory": latest["memory"],
                "disk": latest["disk"],
                "network": latest["network"],
                "interface": latest["interface"],
            },
        }

    def report_summary(self) -> dict:
        monitoring = self.monitoring_summary()
        series = monitoring["series"]
        customer_record = self.report_customer_record()
        metrics = [
            ("cpu", "CPU", 80),
            ("memory", "Memory", 80),
            ("disk", "Disk", 85),
            ("network", "Network", 75),
            ("interface", "Interface", 70),
        ]
        cards = []
        for key, label, threshold in metrics:
            values = [item[key] for item in series]
            current = monitoring["current"][key]
            average = round(sum(values) / len(values), 1)
            peak = round(max(values), 1)
            status = "Warning" if peak >= threshold else "Normal"
            cards.append(
                {
                    "id": key,
                    "label": label,
                    "current": current,
                    "average": average,
                    "peak": peak,
                    "threshold": threshold,
                    "status": status,
                    "recommendation": self.report_recommendation(key, peak, average, threshold),
                }
            )
        warnings = [card for card in cards if card["status"] == "Warning"]
        inspection_items = self.report_inspection_items(cards)
        host_name = socket.gethostname()
        return {
            "title": "Resource Usage Analysis Report",
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "range": monitoring["range"],
            "customer": {
                "customer_name": "OAM Customer",
                "inspection_date": datetime.now().strftime("%Y-%m-%d"),
                "customer_contact": customer_record.get("customer_contact", "-"),
                "engineer": "OAM Lock-FIX",
                "customer_email": customer_record.get("customer_email", "-"),
                "engineer_contact": "1666-3736",
            },
            "server": {
                "os_version": platform.platform(),
                "cpu": "Monitored CPU",
                "service": "LOCK-FIX Hardware Detection Monitoring",
                "memory": f"{next(card for card in cards if card['id'] == 'memory')['current']}% in use",
                "model": "LOCK-FIX PoC",
                "disk": f"{next(card for card in cards if card['id'] == 'disk')['current']}% in use",
                "serial": "POC-LOCAL",
                "hostname": host_name,
            },
            "summary": {
                "overall_status": "Attention Required" if warnings else "Normal",
                "analysis": "Current operating resources are monitored every 5 seconds and summarized with average, peak, and threshold values.",
                "warning_count": len(warnings),
            },
            "cards": cards,
            "inspection_items": inspection_items,
            "series": series,
            "extras": self.report_extras_record(),
            "exports": {
                "word": "/api/report.docx",
                "csv": "/api/report.csv",
                "excel": "/api/report.xlsx",
            },
        }

    def report_recommendation(self, key: str, peak: float, average: float, threshold: float) -> str:
        if peak < threshold:
            return "No immediate action required."
        recommendations = {
            "cpu": "Review high-load processes and scheduled jobs.",
            "memory": "Check resident services and consider memory expansion.",
            "disk": "Clean up old logs/backups or extend storage capacity.",
            "network": "Review traffic bursts and backup transfer windows.",
        }
        return recommendations.get(key, "Review resource usage trend.")

    def report_inspection_items(self, cards: list[dict]) -> list[dict]:
        by_id = {card["id"]: card for card in cards}

        def result(metric_id: str) -> str:
            return "Warning" if by_id[metric_id]["status"] == "Warning" else "Normal"

        return [
            {"category": "H/W", "item": "System LED", "detail": "Front panel LED", "criteria": "No red indicator", "result": "Normal", "metric": "-"},
            {"category": "H/W", "item": "Power Supply", "detail": "Visual inspection", "criteria": "Green indicator", "result": "Normal", "metric": "-"},
            {"category": "H/W", "item": "Disk LED", "detail": "Visual inspection", "criteria": "No red indicator", "result": result("disk"), "metric": f"{by_id['disk']['current']}%"},
            {"category": "H/W", "item": "RAID Status", "detail": "Status check", "criteria": "Online", "result": "Normal", "metric": "Online"},
            {"category": "H/W", "item": "Memory", "detail": "Usage analysis", "criteria": f"< {by_id['memory']['threshold']}%", "result": result("memory"), "metric": f"{by_id['memory']['current']}%"},
            {"category": "H/W", "item": "CPU", "detail": "Usage analysis", "criteria": f"< {by_id['cpu']['threshold']}%", "result": result("cpu"), "metric": f"{by_id['cpu']['current']}%"},
            {"category": "H/W", "item": "Adapter", "detail": "NIC link and cable", "criteria": "Link up", "result": "Normal", "metric": "Link up"},
            {"category": "H/W", "item": "System Log", "detail": "Syslog review", "criteria": "No critical error", "result": "Normal", "metric": "No critical"},
            {"category": "OS", "item": "OS Error", "detail": "/var/log/messages", "criteria": "No error", "result": "Normal", "metric": "No error"},
            {"category": "OS", "item": "Disk Usage", "detail": "Filesystem capacity", "criteria": f"< {by_id['disk']['threshold']}%", "result": result("disk"), "metric": f"{by_id['disk']['current']}%"},
            {"category": "OS", "item": "Performance", "detail": "vmstat / top equivalent", "criteria": "No excessive usage", "result": "Warning" if any(card["status"] == "Warning" for card in cards) else "Normal", "metric": "See metrics"},
            {"category": "OS", "item": "Processor", "detail": "CPU utilization", "criteria": "No abnormal usage", "result": result("cpu"), "metric": f"Peak {by_id['cpu']['peak']}%"},
            {"category": "OS", "item": "Memory Usage", "detail": "Memory utilization", "criteria": "No abnormal usage", "result": result("memory"), "metric": f"Peak {by_id['memory']['peak']}%"},
            {"category": "OS", "item": "Disk I/O", "detail": "Disk capacity trend", "criteria": "Stable", "result": result("disk"), "metric": f"Avg {by_id['disk']['average']}%"},
            {"category": "OS", "item": "Network", "detail": "TX/RX traffic flow", "criteria": f"< {by_id['network']['threshold']}%", "result": result("network"), "metric": f"{by_id['network']['current']}%"},
        ]

    def dashboard_summary(self) -> dict:
        logs = [
            {"type": "WARNING", "date": "2024-12-22 12:03:06", "content": "[MEMORY] 92.75% (Threshold:80.0%)"},
            {"type": "LOGS", "date": "2024-12-22 11:56:07", "content": "rich.kim@oam.co.kr 계정 회원가입 완료"},
            {"type": "WARNING", "date": "2024-12-22 11:53:05", "content": "[MEMORY] 92.65% (Threshold:80.0%)"},
            {"type": "WARNING", "date": "2024-12-22 11:43:04", "content": "[MEMORY] 91.84% (Threshold:80.0%)"},
            {"type": "WARNING", "date": "2024-12-22 11:33:02", "content": "[DISK] 88.20% (Threshold:85.0%)"},
        ]

        return {
            "cards": [
                {"id": "detect", "label": "Detect", "description": "Hardware changes", "value": 0},
                {"id": "warning", "label": "Warning", "description": "Hardware threshold usage", "value": 4},
                {"id": "logs", "label": "Logs", "description": "External server logs", "value": 1},
            ],
            "notifications": self.notification_items(),
            "logs": logs,
            "total_logs": len(logs),
        }

    def notification_items(self) -> list[dict]:
        return [
            {
                "email": "rich.kim@oam.co.kr",
                "smtp_status": "Connected",
                "network_connection": "NOT Connection",
                "last_login": "2024-12-03 15:14:58",
            },
            {
                "email": "rich.kim@oam.co.kr",
                "smtp_status": "Connected",
                "network_connection": "GOOD",
                "last_login": "2024-12-22 20:57:39",
            },
        ]

    def detect_summary(self) -> dict:
        warning_items = [
            {"date": "2024-12-22 13:30", "event": "[MEMORY] 93.25% (임계:80%)"},
            {"date": "2024-12-22 13:20", "event": "[MEMORY] 92.65% (임계:80%)"},
            {"date": "2024-12-22 13:10", "event": "[MEMORY] 92.75% (임계:80%)"},
            {"date": "2024-12-22 13:05", "event": "[MEMORY] 92.90% (임계:80%)"},
            {"date": "2024-12-22 13:03", "event": "[MEMORY] 92.62% (임계:80%)"},
            {"date": "2024-12-22 13:03", "event": "[MEMORY] 92.62% (임계:80%)"},
            {"date": "2024-12-22 13:03", "event": "[MEMORY] 92.68% (임계:80%)"},
        ]
        log_items = [
            {"date": "2024-12-20 56:07", "event": "rich.kim@oam.co.kr 계정 회원가입 완료"},
        ]
        return {
            "range": {"start": "2024-12-22", "end": "2024-12-22"},
            "cards": [
                {"id": "detect", "label": "Detect", "description": "하드웨어의 변경(추가,", "value": 0},
                {"id": "warning", "label": "Warning", "description": "하드웨어의 초과 사용", "value": len(warning_items)},
                {"id": "logs", "label": "Logs", "description": "이외의 서버 로그", "value": len(log_items)},
            ],
            "detect": [],
            "warning": warning_items,
            "logs": log_items,
        }

    def network_status_summary(self) -> dict:
        tick = int(time.time() / 5)
        names = [
            "112.148.194.115",
            "127.0.0.1",
            "172.16.0.12",
            "192.168.0.10",
            "10.10.1.21",
            "10.10.1.22",
            "10.10.1.23",
            "10.10.1.24",
            "10.10.1.25",
            "10.10.1.26",
            "10.10.1.27",
            "10.10.1.28",
            "oam-datacenter",
            "web-solution",
            "backup-node",
            "license-server",
            "smtp.oam.co.kr",
            "monitoring-api",
            "remote-support",
            "storage-gateway",
            "eth0",
            "eth1",
            "bond0",
            "vmbr0",
        ]
        items = []
        tx_history = []
        rx_history = []
        for index, name in enumerate(names):
            tx = 0.55 + (((index * 7) + tick) % 13) * 0.08
            rx = 0.92 + (((index * 11) + tick * 2) % 19) * 0.1
            if index == 0:
                tx, rx = 2.2 + (tick % 5) * 0.18, 6.1 + (tick % 7) * 0.22
            elif index in (1, 2):
                tx = 2.9 - index * 0.3 + (tick % 4) * 0.12
                rx = 4.2 - index * 0.25 + (tick % 6) * 0.16
            items.append(
                {
                    "target": name,
                    "tx_gb": round(tx, 2),
                    "rx_gb": round(rx, 2),
                    "bandwidth_kb": 1024 * (100 + index * 10),
                }
            )
        for index in range(28):
            tx_history.append(round(18 + (((index + tick) * 9) % 27) + (6 if (index + tick) % 9 == 0 else 0), 1))
            rx_history.append(round(34 + (((index + tick) * 13) % 39) + (8 if (index + tick) % 9 == 0 else 0), 1))
        return {
            "title": "실시간 IP 별 누적 트래픽",
            "unit": "GB",
            "interval_seconds": 10,
            "realtime": {
                "tx": {
                    "label": "송신",
                    "current_mbps": tx_history[-1],
                    "total_gb": round(sum(item["tx_gb"] for item in items), 2),
                    "history": tx_history,
                },
                "rx": {
                    "label": "수신",
                    "current_mbps": rx_history[-1],
                    "total_gb": round(sum(item["rx_gb"] for item in items), 2),
                    "history": rx_history,
                },
            },
            "items": items,
        }

    def log_items(self, start_date: str = "", end_date: str = "", retention_days: int = 30) -> tuple[list[dict], datetime, datetime]:
        now = datetime.now()
        range_end = datetime(now.year, now.month, now.day, 23, 59, 59)
        range_start = range_end - timedelta(days=retention_days - 1)
        try:
            if start_date:
                range_start = datetime.strptime(start_date, "%Y-%m-%d")
            if end_date:
                range_end = datetime.strptime(end_date, "%Y-%m-%d") + timedelta(hours=23, minutes=59, seconds=59)
            if range_end < range_start:
                range_end = range_start + timedelta(hours=23, minutes=59, seconds=59)
        except ValueError:
            range_end = datetime(now.year, now.month, now.day, 23, 59, 59)
            range_start = range_end - timedelta(days=retention_days - 1)

        retention_start = datetime(now.year, now.month, now.day) - timedelta(days=retention_days - 1)
        range_start = max(range_start, retention_start)
        templates = [
            ("WARNING", "performance", "WARN", "[MEMORY] {memory}% (임계:80.0%)"),
            ("DETECT", "hardware", "INFO", "[NIC] eth0 link status verified"),
            ("SYSLOG", "systemd", "INFO", "lockfix-monitor.service heartbeat ok"),
            ("SYSLOG", "network", "INFO", "vmbr0 rx/tx counters updated"),
            ("LOGS", "account", "INFO", "dashboard data export request completed"),
        ]
        items = []
        for day_offset in range(retention_days):
            day = datetime(now.year, now.month, now.day) - timedelta(days=day_offset)
            for index, (kind, source, severity, message) in enumerate(templates):
                stamp = day.replace(hour=13 - index, minute=(3 + day_offset + index * 7) % 60, second=13 if index == 0 else 0)
                if stamp < range_start or stamp > range_end:
                    continue
                memory = round(91.8 + ((day_offset + index) % 8) * 0.17, 4)
                items.append(
                    {
                        "type": kind,
                        "date": stamp.strftime("%Y-%m-%d %H:%M:%S"),
                        "source": source,
                        "severity": severity,
                        "message": message.format(memory=memory),
                    }
                )
        for item in self.audit_items()[:50]:
            event = str(item.get("event", "audit_event"))
            severity = "WARN" if "warning" in event or "expired" in event or "failed" in event else "INFO"
            raw_date = str(item.get("ts", "-"))[:19]
            try:
                stamp = datetime.fromisoformat(raw_date)
            except ValueError:
                continue
            if stamp < range_start or stamp > range_end or stamp < retention_start:
                continue
            items.append(
                {
                    "type": "SYSLOG",
                    "date": raw_date,
                    "source": "license" if event.startswith("license") else "audit",
                    "severity": severity,
                    "message": event,
                }
            )
        items.sort(key=lambda item: item["date"], reverse=True)
        return items, range_start, range_end

    def retention_days(self, value: str = "30") -> int:
        try:
            days = int(value)
        except ValueError:
            days = 30
        return min(100, max(30, days))

    def logs_summary(self, start_date: str = "", end_date: str = "", page_value: str = "1", retention_value: str = "30") -> dict:
        retention_days = self.retention_days(retention_value)
        items, range_start, range_end = self.log_items(start_date, end_date, retention_days)
        per_page = 30
        try:
            page = max(1, int(page_value))
        except ValueError:
            page = 1
        total_pages = max(1, (len(items) + per_page - 1) // per_page)
        page = min(page, total_pages)
        offset = (page - 1) * per_page
        return {
            "range": {"start": range_start.strftime("%Y-%m-%d"), "end": range_end.strftime("%Y-%m-%d")},
            "total_logs": len(items),
            "page": page,
            "per_page": per_page,
            "total_pages": total_pages,
            "retention_days": retention_days,
            "items": items[offset : offset + per_page],
        }

    def send_logs_csv(self, start_date: str = "", end_date: str = "", retention_value: str = "30") -> None:
        items, _, _ = self.log_items(start_date, end_date, self.retention_days(retention_value))
        rows = ["type,date,source,severity,message"]
        for item in items:
            rows.append(",".join(str(item[key]).replace('"', '""').join(['"', '"']) for key in ("type", "date", "source", "severity", "message")))
        self.send_download(("\n".join(rows) + "\n").encode("utf-8-sig"), "text/csv; charset=utf-8", "lockfix_logs.csv")

    def send_monitoring_csv(self, start_date: str = "", end_date: str = "") -> None:
        data = self.monitoring_summary(start_date, end_date)
        rows = ["time,cpu_usage,memory_usage,disk_usage,network_usage,interface_usage"]
        for item in data["series"]:
            rows.append(f"{item['time']},{item['cpu']},{item['memory']},{item['disk']},{item['network']},{item['interface']}")
        body = ("\n".join(rows) + "\n").encode("utf-8-sig")
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header("Content-Disposition", "attachment; filename=monitoring.csv")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.end_headers()
        self.write_body(body)

    def send_report_csv(self) -> None:
        report = self.report_summary()
        extras = report["extras"]
        opinion = extras["engineer_opinion"].replace('"', '""')
        rows = ["section,item,value,item2,value2"]
        rows.append(f"customer,Customer Name,{report['customer']['customer_name']},Inspection Date,{report['customer']['inspection_date']}")
        rows.append(f"customer,Customer Contact,{report['customer']['customer_contact']},Engineer,{report['customer']['engineer']}")
        rows.append(f"server,OS Version,\"{report['server']['os_version']}\",CPU,{report['server']['cpu']}")
        rows.append(f"server,Service,\"{report['server']['service']}\",Memory,{report['server']['memory']}")
        rows.append(f"engineer_opinion,Content,\"{opinion}\",,")
        rows.append(f"signature,Engineer Inspection Signature,{'Attached' if extras['engineer_signature'] else '-'},Manager Signature,{'Attached' if extras['manager_signature'] else '-'}")
        rows.append("")
        rows.append("section,metric,current,average,peak,threshold,status,recommendation")
        for card in report["cards"]:
            rows.append(
                ",".join(
                    [
                        "summary",
                        card["label"],
                        str(card["current"]),
                        str(card["average"]),
                        str(card["peak"]),
                        str(card["threshold"]),
                        card["status"],
                        '"' + card["recommendation"].replace('"', '""') + '"',
                    ]
                )
            )
        rows.append("")
        rows.append("category,item,detail,criteria,metric,result")
        for item in report["inspection_items"]:
            rows.append(
                f"{item['category']},{item['item']},\"{item['detail']}\",\"{item['criteria']}\",{item['metric']},{item['result']}"
            )
        rows.append("")
        rows.append("time,cpu,memory,disk,network")
        for item in report["series"]:
            rows.append(f"{item['time']},{item['cpu']},{item['memory']},{item['disk']},{item['network']}")
        self.send_download(("\n".join(rows) + "\n").encode("utf-8-sig"), "text/csv; charset=utf-8", "lockfix_report.csv")

    def send_report_xlsx(self) -> None:
        report = self.report_summary()
        extras = report["extras"]
        rows = [
            ["Customer / Inspection Information"],
            ["Customer Name", report["customer"]["customer_name"], "Inspection Date", report["customer"]["inspection_date"]],
            ["Customer Contact", report["customer"]["customer_contact"], "Engineer", report["customer"]["engineer"]],
            ["Customer Email", report["customer"]["customer_email"], "Engineer Contact", report["customer"]["engineer_contact"]],
            [],
            ["Server Basic Information"],
            ["OS Version", report["server"]["os_version"], "CPU", report["server"]["cpu"]],
            ["Service", report["server"]["service"], "Memory", report["server"]["memory"]],
            ["Model", report["server"]["model"], "Disk", report["server"]["disk"]],
            ["S/N", report["server"]["serial"], "Hostname", report["server"]["hostname"]],
            [],
            ["Engineer Opinion"],
            ["Content", extras["engineer_opinion"] or "-"],
            ["Electronic Signature"],
            ["Engineer Inspection Signature", "Attached" if extras["engineer_signature"] else "-"],
            ["Manager Signature", "Attached" if extras["manager_signature"] else "-"],
            [],
            ["Metric", "Current", "Average", "Peak", "Threshold", "Status", "Recommendation"],
            *[
                [
                    card["label"],
                    card["current"],
                    card["average"],
                    card["peak"],
                    card["threshold"],
                    card["status"],
                    card["recommendation"],
                ]
                for card in report["cards"]
            ],
            [],
            ["Category", "Inspection Item", "Details", "Criteria", "Metric", "Result"],
            *[
                [item["category"], item["item"], item["detail"], item["criteria"], item["metric"], item["result"]]
                for item in report["inspection_items"]
            ],
            [],
            ["Time", "CPU", "Memory", "Disk", "Network"],
            *[[item["time"], item["cpu"], item["memory"], item["disk"], item["network"]] for item in report["series"]],
        ]
        body = self.build_xlsx(rows)
        self.send_download(
            body,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "lockfix_report.xlsx",
        )

    def send_report_docx(self) -> None:
        report = self.report_summary()
        body = self.build_docx(report)
        self.send_download(
            body,
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "lockfix_report.docx",
        )

    def build_xlsx(self, rows: list[list[object]]) -> bytes:
        def cell_ref(row_index: int, col_index: int) -> str:
            letters = ""
            col = col_index
            while col:
                col, remainder = divmod(col - 1, 26)
                letters = chr(65 + remainder) + letters
            return f"{letters}{row_index}"

        sheet_rows = []
        for row_index, row in enumerate(rows, start=1):
            cells = []
            for col_index, value in enumerate(row, start=1):
                ref = cell_ref(row_index, col_index)
                if isinstance(value, (int, float)):
                    cells.append(f'<c r="{ref}"><v>{value}</v></c>')
                else:
                    cells.append(f'<c r="{ref}" t="inlineStr"><is><t>{escape(str(value))}</t></is></c>')
            sheet_rows.append(f'<row r="{row_index}">{"".join(cells)}</row>')
        sheet = f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>{"".join(sheet_rows)}</sheetData></worksheet>'
        output = io.BytesIO()
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
            archive.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
            archive.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Report" sheetId="1" r:id="rId1"/></sheets></workbook>')
            archive.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
            archive.writestr("xl/worksheets/sheet1.xml", sheet)
        return output.getvalue()

    def build_docx(self, report: dict) -> bytes:
        def para(text: str, style: str = "") -> str:
            props = ""
            if style == "title":
                props = '<w:pPr><w:jc w:val="center"/></w:pPr>'
                run = f'<w:r><w:rPr><w:b/><w:sz w:val="36"/><w:color w:val="0B2E79"/></w:rPr><w:t>{escape(text)}</w:t></w:r>'
            elif style == "section":
                run = f'<w:r><w:rPr><w:b/><w:sz w:val="24"/><w:color w:val="0B2E79"/></w:rPr><w:t>{escape(text)}</w:t></w:r>'
            else:
                run = f'<w:r><w:rPr><w:sz w:val="20"/></w:rPr><w:t>{escape(text)}</w:t></w:r>'
            return f"<w:p>{props}{run}</w:p>"

        def cell(text: object, shaded: bool = False) -> str:
            shade = '<w:shd w:fill="EEF3F7"/>' if shaded else ""
            return (
                "<w:tc><w:tcPr>"
                f"{shade}<w:tcMar><w:top w:w=\"90\" w:type=\"dxa\"/><w:left w:w=\"90\" w:type=\"dxa\"/><w:bottom w:w=\"90\" w:type=\"dxa\"/><w:right w:w=\"90\" w:type=\"dxa\"/></w:tcMar>"
                "</w:tcPr><w:p><w:r><w:rPr><w:sz w:val=\"18\"/></w:rPr><w:t>"
                + escape(str(text))
                + "</w:t></w:r></w:p></w:tc>"
            )

        def table(rows: list[list[object]], header: bool = False) -> str:
            trs = []
            for index, row in enumerate(rows):
                trs.append("<w:tr>" + "".join(cell(value, shaded=header and index == 0) for value in row) + "</w:tr>")
            return (
                '<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/>'
                '<w:tblBorders><w:top w:val="single" w:sz="4" w:color="D9E2EA"/><w:left w:val="single" w:sz="4" w:color="D9E2EA"/><w:bottom w:val="single" w:sz="4" w:color="D9E2EA"/><w:right w:val="single" w:sz="4" w:color="D9E2EA"/><w:insideH w:val="single" w:sz="4" w:color="D9E2EA"/><w:insideV w:val="single" w:sz="4" w:color="D9E2EA"/></w:tblBorders>'
                "</w:tblPr>"
                + "".join(trs)
                + "</w:tbl>"
            )

        def image_para(rel_id: str, name: str) -> str:
            return (
                '<w:p><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0" '
                'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing">'
                '<wp:extent cx="3048000" cy="914400"/><wp:docPr id="1" name="'
                + escape(name)
                + '"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
                '<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
                '<pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
                '<pic:nvPicPr><pic:cNvPr id="0" name="'
                + escape(name)
                + '"/><pic:cNvPicPr/></pic:nvPicPr>'
                '<pic:blipFill><a:blip r:embed="'
                + rel_id
                + '"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
                '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="3048000" cy="914400"/></a:xfrm>'
                '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
                '</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>'
            )

        extras = report["extras"]
        signature_media = []
        signature_blocks = []
        for field, rel_id, filename, label in [
            ("engineer_signature", "rIdEngineerSignature", "engineer_signature.png", "Engineer Inspection Signature"),
            ("manager_signature", "rIdManagerSignature", "manager_signature.png", "Manager Signature"),
        ]:
            image_bytes = self.image_data_url_bytes(extras.get(field, ""))
            if image_bytes:
                signature_media.append((rel_id, filename, image_bytes))
                signature_blocks.extend([para(label, "section"), image_para(rel_id, label)])

        customer_rows = [
            ["Customer Name", report["customer"]["customer_name"], "Inspection Date", report["customer"]["inspection_date"]],
            ["Customer Contact", report["customer"]["customer_contact"], "Engineer", report["customer"]["engineer"]],
            ["Customer Email", report["customer"]["customer_email"], "Engineer Contact", report["customer"]["engineer_contact"]],
        ]
        server_rows = [
            ["OS Version", report["server"]["os_version"], "CPU", report["server"]["cpu"]],
            ["Service", report["server"]["service"], "Memory", report["server"]["memory"]],
            ["Model", report["server"]["model"], "Disk", report["server"]["disk"]],
            ["S/N", report["server"]["serial"], "Hostname", report["server"]["hostname"]],
        ]
        resource_rows = [
            ["Metric", "Current", "Average", "Peak", "Threshold", "Result", "Recommendation"],
            *[
                [
                    card["label"],
                    f"{card['current']}%",
                    f"{card['average']}%",
                    f"{card['peak']}%",
                    f"{card['threshold']}%",
                    card["status"],
                    card["recommendation"],
                ]
                for card in report["cards"]
            ],
        ]
        inspection_rows = [
            ["Category", "Inspection Item", "Details", "Criteria", "Metric", "Result"],
            *[
                [item["category"], item["item"], item["detail"], item["criteria"], item["metric"], item["result"]]
                for item in report["inspection_items"]
            ],
        ]
        time_rows = [
            ["Time", "CPU", "Memory", "Disk", "Network"],
            *[[item["time"], f"{item['cpu']}%", f"{item['memory']}%", f"{item['disk']}%", f"{item['network']}%"] for item in report["series"][-10:]],
        ]
        signature_rows = [
            ["Engineer Inspection Signature", "Attached" if extras["engineer_signature"] else "-"],
            ["Manager Signature", "Attached" if extras["manager_signature"] else "-"],
        ]

        body = [
            para("System Inspection Report", "title"),
            para(f"Report No. #1    Generated: {report['generated_at']}"),
            para(f"Overall Status: {report['summary']['overall_status']}"),
            para(report["summary"]["analysis"]),
            para("Customer / Inspection Information", "section"),
            table(customer_rows),
            para("Server Basic Information", "section"),
            table(server_rows),
            para("Resource Usage Analysis", "section"),
            table(resource_rows, header=True),
            para("Server Inspection Checklist", "section"),
            table(inspection_rows, header=True),
            para("Engineer Opinion", "section"),
            para(extras["engineer_opinion"] or "-"),
            para("Electronic Signature", "section"),
            table(signature_rows),
            *signature_blocks,
            para("Recent Monitoring Samples", "section"),
            table(time_rows, header=True),
        ]
        document = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:body>'
            + "".join(body)
            + '<w:sectPr><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="850" w:right="720" w:bottom="850" w:left="720" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>'
        )
        output = io.BytesIO()
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
            png_default = '<Default Extension="png" ContentType="image/png"/>' if signature_media else ""
            archive.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' + png_default + '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
            archive.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
            if signature_media:
                relationships = [
                    f'<Relationship Id="{rel_id}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/{filename}"/>'
                    for rel_id, filename, _ in signature_media
                ]
                archive.writestr("word/_rels/document.xml.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + "".join(relationships) + "</Relationships>")
                for _, filename, image_bytes in signature_media:
                    archive.writestr(f"word/media/{filename}", image_bytes)
            archive.writestr("word/document.xml", document)
        return output.getvalue()

    def send_download(self, body: bytes, content_type: str, filename: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f"attachment; filename={filename}")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.end_headers()
        self.write_body(body)

    def serve_file(self, path: Path) -> None:
        if not path.exists() or not path.is_file():
            self.send_error(404, "not found")
            return
        content_type = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.end_headers()
        self.write_body(data)

    def send_json(self, payload: dict, status: int = 200, headers=None) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.write_body(data)

    def write_body(self, body: bytes) -> None:
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
            return


def run(host: str = "127.0.0.1", port: int = 8088, config_path: Path = DEFAULT_CONFIG) -> None:
    LockFixWebHandler.context = WebContext(config_path)
    server = ThreadingHTTPServer((host, port), LockFixWebHandler)
    print(f"LOCK-FIX PoC UI: http://{host}:{port}")
    print(f"Config: {config_path}")
    server.serve_forever()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8088)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    args = parser.parse_args()
    run(args.host, args.port, args.config.resolve())

